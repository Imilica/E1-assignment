import { test, expect } from '@fixtures';

test.use({ storageState: { cookies: [], origins: [] } });

// Temporary spec: proves failure artifacts (screenshot, video, trace) are captured.
test('DEMO: login error text is wrong on purpose', async ({ loginPage }) => {
  await loginPage.goto();
  await loginPage.login('nobody@example.com', 'Wrong-Pass1!');
  await expect(loginPage.errorMessage).toHaveText('This text is deliberately wrong');
});
